from django.urls import path

from .views import (ExecuteTrades, GenerateBacktestIndData,
                    GeneratePredictions, MlModelsView, MlModelsViewInfo,
                    ModelDataView,GenerateBacktestResults,UpdateShortTrades,CloseTrades)

urlpatterns = [
    path('generatedata/', ModelDataView.as_view()),
    path('addmodel/',MlModelsView.as_view()),
    path('getmodel/',MlModelsViewInfo.as_view()),
    path('generatepredictions/',GeneratePredictions.as_view()),
    path('executetrades/',ExecuteTrades.as_view()),
    path('generateind/',GenerateBacktestIndData.as_view()),
    path('generatebtpred/',GenerateBacktestResults.as_view()),
    path('shortupdate/',UpdateShortTrades.as_view()),
    path('closepositions/',CloseTrades.as_view())
]
