import ast
import pickle
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
from math import ceil, floor
from nis import maps
import stat
from traceback import print_tb
from types import new_class
from unicodedata import name
from xml.sax.handler import all_features
from django.forms import ValidationError
import exchange_calendars as xcals
import numpy as np
import pandas as pd
import gc
import requests
from django.shortcuts import render
from joblib import Parallel, delayed, parallel_backend
from pyexpat import features, model
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from tqdm import tqdm
import ast
from .BrokerAPi import AlpacaBroker
from .DataDownloader import DataDownload
from .DataPreprocessing import GenerateFeatures
from .models import ( MLModels, ModelData, Positions,
                     Predictions,BacktestPredictions)
from .PredictionGenerator import PredictionGenerator
from .serializers import ( MLModelsSerializer,
                          ModelDataSerializer, PositionsSerializer,
                          PredictionSerializer,BackTestPredictionSerializer)
import time as tm


class ModelDataView(APIView):

    def get_all_features(self):
        model_ = MLModels.objects.all()
        serializer = MLModelsSerializer(model_,many= True)
        serializer_data = serializer.data
        features = []
   
        for data in serializer_data:
            features += data['features']
        features = list(set(features))
        return features


    def post(self, request):
        all_features_ = self.get_all_features()
        data_handler = GenerateFeatures(all_features=all_features_)
        serializer = ModelDataSerializer(data=request.data)
        df = data_handler.generate_data(request.data)
        js_ = df.to_json()
        request.data['indicatorsdata'] = js_
        if serializer.is_valid():    
            serializer.save()
            return Response({"status": "success", "data": serializer.data}, status=status.HTTP_200_OK)
        else:
            print(serializer.errors)
            return Response({"status": "error", "data": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)




class MlModelsView(APIView):
    
    def post(self,request):
        serializer = MLModelsSerializer(data=request.data)
        # print(request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"status": "success", "data": serializer.data}, status=status.HTTP_200_OK)
        else:
            print(serializer.errors)
            return Response({"status": "error", "data": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
    


class MlModelsViewInfo(APIView):

    def get(self,request):
        model_id = self.request.query_params.get('name')
        print(model_id)
        model_ = MLModels.objects.filter(name = model_id).first()
        serializer = MLModelsSerializer(model_)
        return Response({"status": "success", "data": serializer.data}, status=status.HTTP_200_OK)


class GeneratePredictions(APIView):
    

    def get(self,request):
        pred_gen = PredictionGenerator()
        model_ = MLModels.objects.all()
        serializer = MLModelsSerializer(model_,many= True)
        date_today = datetime.today().date()
        ind_data = ModelData.objects.filter(time_created = date_today).first()
        indicators_serilizer = ModelDataSerializer(ind_data).data['indicatorsdata']
        indicators_serilizer = ast.literal_eval(indicators_serilizer)
        new_data = {}
        for i in indicators_serilizer.keys():
            new_data[i] = list(indicators_serilizer[i].values())
        new_data = pd.DataFrame(new_data)
        predictions = {}
        for i in serializer.data:
            predictions['model_name'] = i['name']
            predictions['predictions'] = pred_gen.get_prediction(new_data,i)
            if predictions['predictions'] is not None:
                predictions['predictions'] = predictions['predictions'].to_dict()
                print(predictions,"\n\n************************************")
                predictions_serializer = PredictionSerializer(data = predictions)
                if predictions_serializer.is_valid():
                    predictions_serializer.save()
                else:
                    print(predictions_serializer.errors)

        return Response({"status": "success"}, status=status.HTTP_200_OK)





class ExecuteTrades(APIView):

    def open_position_to_close(self):
        date_today = datetime.today().date()
        open_positions  = Positions.objects.filter(close_date = date_today,status = 'Open').all()
        pos_serializer = PositionsSerializer(open_positions,many = True)
        return True if len(pos_serializer.data)>0 else 1


    def get_next_trading_day(self,n = 3):
        xnys = xcals.get_calendar("XNYS")
        next_date = datetime.now() + timedelta(days=n)
        next_date  = next_date.date()
        itr = n
        if xnys.is_session(str(next_date)):
           return  next_date
        else:
            while True:
                itr = itr+1
                next_date = datetime.now() + timedelta(days=itr)
                next_date  = next_date.date()
                if xnys.is_session(str(next_date)):
                    return  next_date





    # def close_positions(self):

    #Function to distribute money evenly within strategy
    def get_distributions(self,a,amount,price_):
        responses = []
        consumed = 0
        distribution = {}
        all = [a]
        #  ADD ALL stocks
        total_no_strategies = 1
        portfolio = amount
        start_money = 0

        for i in all:
            inside_len = len(i)
            startegy_ratio = 1 / total_no_strategies
            inside_len_ratio = 1 / inside_len
            for z in i:
                price = price_[z]
                if z.split('_')[0] not in list(distribution.keys()):
                    if z.split('_')[0] in ['BTCUSD', 'ETHUSD']:
                        distribution[z.split('_')[0]] = (
                            max(start_money, portfolio) *
                            (startegy_ratio * inside_len_ratio)) / price
                    else:
                        distribution[z.split('_')[0]] = floor(
                            (max(start_money, portfolio) *
                            (startegy_ratio * inside_len_ratio)) / price)
                else:
                    if z.split('_')[0] not in ['BTCUSD', 'ETHUSD']:
                        distribution[z.split(
                            '_')[0]] = distribution[z.split('_')[0]] + floor(
                                (max(start_money, portfolio) *
                                (startegy_ratio * inside_len_ratio)) / price)
                    else:
                        distribution[z.split('_')[0]] = distribution[z.split('_')[
                            0]] + (max(start_money, portfolio) *
                                (startegy_ratio * inside_len_ratio)) / price
            
        dist_ = {}
        for i in distribution:
            if not distribution[i] == 0 :
                dist_[i] = distribution[i]

        if len(dist_) == 0:
            print('\n',"All Zero ",all,'\n')

        return dist_





    def get(self,request):

        try:

            ####Check already Opened Positions
            short = self.request.query_params.get('short')
            if short == None:
                short = 'False'
            
            short = True if short.lower() == 'true' else False 

            ###get broker Instance 
            broker = AlpacaBroker()

            ###### Data DOwnloader
            data_downloader = DataDownload()


            if not self.open_position_to_close():

                print("No Open Positions to Close")

            ####get Available Cash
            totalCash = broker.get_cash_in_hand()

            ######debug 
            # totalCash = 65000
            
            print("\ntotal Cash In Hand : " , totalCash )

            ####Models Data Fetch n=and get weights
            
            model_ = MLModels.objects.all()
            serializer = MLModelsSerializer(model_,many= True)
            model_amount = {}
            model_side = {}
            for model in serializer.data:
                model_amount[model['name']] = ceil(float(model['weight']) * float(totalCash))
                model_side[model['name']] = model['side']

            print(model_amount)
            #########Prediction Data Fetch
            date_today = datetime.today().date()
            pred_data = Predictions.objects.select_related().filter(time_created = date_today).all()
            pred_serilizer = PredictionSerializer(pred_data,many = True)
            predictions_data = pred_serilizer.data

            models_ = {}
            for data_ in predictions_data:
                models_[data_['model_name']] = list(data_['predictions']['ticker'].values())
            all_tickers = []
            for ticks in models_.values():
                all_tickers = all_tickers + ticks


            with ThreadPoolExecutor(max_workers=600) as pool:
                results = pool.map(data_downloader.prefetch_v, all_tickers)
            prices = {}
            for i in results:
                prices[list(i.keys())[0]] = list(i.values())[0]

            distributions = {}
            for i in models_.keys():
                print("******************************")        
                print(models_[i],model_amount[i])
                print("-------------------------------")
                if len(models_[i]) > 0:
                    distributions[i] = self.get_distributions(models_[i],model_amount[i],prices)

            print("All Models Distributions : " , distributions.keys() )
            dist_ = {}
            if short:
                for i in distributions:
                    if 'short' in i:
                        dist_[i] = distributions[i]
                distributions = dist_
            
            print(distributions.keys())

            for i in distributions:
            
                side = model_side[i].lower()
                orders_to_send = []
                position_data = {}
                
                for ticker in distributions[i]:
                    orders_to_send.append((ticker,distributions[i][ticker],side))

                    
                results = broker.open_positions(orders_to_send)

                print("*******************\n")
                print(results)
                print("********************\n")

                position_data['model_name'] = i
                position_data['type'] = side
                position_data['data'] = results
                position_data['status'] = 'open'
                if '3D' in i:
                    position_data['close_date'] = self.get_next_trading_day(n=3)
                else:
                    position_data['close_date'] = self.get_next_trading_day(n=1)


                position_serializer = PositionsSerializer(data = position_data)    
                if position_serializer.is_valid():
                    position_serializer.save()
                else:
                    print(position_serializer.errors)

        except Exception as e:
            return Response(data = {'status ':e},status=status.HTTP_417_EXPECTATION_FAILED)

        return Response(data = {'status ':'Completed'},status=status.HTTP_200_OK)




class GenerateBacktestIndData(APIView):
    
    def get_all_tickers(self):
        model_ = MLModels.objects.all()
        serializer = MLModelsSerializer(model_,many= True)
        serializer_data = serializer.data
        all_tickers = []
   
        for data in serializer_data:
            # print(data['tickers'])
            all_tickers += data['tickers']
        all_tickers = list(set(all_tickers))
        return all_tickers

    def get_all_features(self):
        model_ = MLModels.objects.all()
        serializer = MLModelsSerializer(model_,many= True)
        serializer_data = serializer.data
        features = []
   
        for data in serializer_data:
            features += data['features']
        features = list(set(features))
        return features

    def post(self, request):
        try:
            all_tickers = self.get_all_tickers()
            all_features_ = self.get_all_features()
            data_handler = GenerateFeatures(tickers=all_tickers,backtest=True,all_features=all_features_)
            df = data_handler.generate_data(request.data)
            gc.collect()
            print("Data Generated Now Saving In Bucket")
            df.to_hdf('file.h5', key='stage', mode='w')
            return Response({"status": "Ok",}, status=status.HTTP_200_OK)
        except :
            return Response({"status": "error",}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)




class GenerateBacktestResults(APIView):

    def get(self,request):
        pred_gen  = PredictionGenerator(backtest=True)
        model_ = MLModels.objects.all()
        serializer = MLModelsSerializer(model_,many= True)
        date_today = datetime.today().date()
        new_data = pd.read_hdf('file.h5')
        predictions = {}
        for i in serializer.data:
            predictions['model_name'] = i['name']
            predictions['predictions'] = pred_gen.get_prediction(new_data,i)
            if predictions['predictions'] is not None:
                predictions['predictions']['Date'] = predictions['predictions']['Date'].apply(lambda x: str(x))
            print(predictions)
            if predictions['predictions'] is not None:
                predictions['predictions'] = predictions['predictions'].to_dict()
                predictions_serializer = BackTestPredictionSerializer(data = predictions)
                if predictions_serializer.is_valid():
                    predictions_serializer.save()
                else:
                    print(predictions_serializer.errors)
        return Response({"status": "success"}, status=status.HTTP_200_OK)


class UpdateShortTrades(APIView):
    
    def get_object(self,name_):
       
        try:
            return Positions.objects.get(model_name= name_,status = 'open')
        except (Positions.DoesNotExist,ValidationError):
            raise status.HTTP_400_BAD_REQUEST

            

    def patch(self,request):
        try:
            models = list(request.data.values())
            broker = AlpacaBroker()
            instances = []

            for name in models:
                try:
                    inst = self.get_object(name_= name)
                    inst.data = broker.update_order_details(inst.data)
                    inst.save()
                    instances.append(inst)            
                except Exception as e:
                    print("No Positions for this model")            
            ser = PositionsSerializer(data=instances,many = True)
            ser.is_valid()
            return Response({'updated':ser.data},status=status.HTTP_200_OK)
        except Exception as e :
            return Response({'Error':ser.errors},status=status.HTTP_400_BAD_REQUEST)

        # positions = Positions.objects.filter(name__in = names,status = 'open')


        # print(positions)


        # positions_data = PositionsSerializer(data=positions,may=True)
        # for i in positions_data.data:


class CloseTrades(APIView):

    def get_positions(self):
        date_today = datetime.now().date()
        obj = Positions.objects.filter(status = 'open',close_date = date_today).all()
        pos_ser = PositionsSerializer(obj,many=True)
        return pos_ser

    def merge_buy_sell_data(self,obj_,result):
        obj_['sell'] = result
        return obj_

    def patch(self,request):
        try:
            broker = AlpacaBroker()
            positions = self.get_positions()
            instances = []
            for i in positions.data:

                row = dict(i)
                order_data = row['data']
                close_date = row['close_date']
                id_ = row['id']
                side = row['type']
                
                if  side == 'long' :
                    side = 'short'
                elif side == 'short' :
                    side = 'long'

                orders_to_send = []
                for i in order_data:
                    if i != 'errors' :
                        orders_to_send.append((i,order_data[i]['filled_qty'],side))
                try:
                    res =  broker.open_positions(orders_to_send,close=True)
                except Exception as e :
                    print('Exception Occured ',e)
                
                obj = Positions.objects.get(id=id_)
                obj.data = self.merge_buy_sell_data(obj.data,res)
                obj.status = 'closed'
                obj.save()
                instances.append(obj)

            ser = PositionsSerializer(data = instances , many = True )
            ser.is_valid()
            return Response({'updated':ser.data},status=status.HTTP_200_OK)
        except Exception as e:
            print("Error Occured",e)
            return Response(data = {'status ':e},status=status.HTTP_417_EXPECTATION_FAILED)
        

        




