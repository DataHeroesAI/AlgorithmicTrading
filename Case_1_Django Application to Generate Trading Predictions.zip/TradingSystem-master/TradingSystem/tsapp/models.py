from email.policy import default
from pyexpat import features
from statistics import mode
from django.db import models
from django.contrib.postgres.fields import ArrayField
import json
from datetime import date



# Create your models here.
class ModelData(models.Model):
    strategy_type = models.CharField(max_length=10)
    time_created = models.DateField(("Date"), default=date.today,unique=True)
    indicatorsdata = models.JSONField(default = dict)


class MLModels(models.Model):
    name = models.CharField(max_length = 450,unique= True,null=False)
    side = models.CharField(max_length = 10, null = False)
    model_path = models.CharField(max_length = 450,null=False,unique=False)
    scaler_path = models.CharField(max_length=450,null=True)
    features = ArrayField(models.CharField(max_length=300,null=False), blank=False)
    weight = models.FloatField(null=False,default = 0.06)
    threshold = models.FloatField(default = 0.5)
    tickers = ArrayField(models.CharField(max_length=300,null=False), blank=False,default=list)
    time_created = models.DateField(("Date"), default=date.today,unique=False)



class Predictions(models.Model):
    model_name = models.ForeignKey(MLModels,
        on_delete=models.CASCADE,
        to_field='name',db_column='modelname')
    predictions = models.JSONField(default = dict)
    time_created = models.DateField(("Date"), default=date.today,unique=False)
    class Meta:
        unique_together = ('time_created', 'model_name')



class Positions(models.Model):
    model_name = models.ForeignKey(MLModels,
        on_delete=models.CASCADE,
        to_field='name',db_column='modelname')
    time_created = models.DateField(("Date"), default=date.today,unique=False)
    type = models.CharField(max_length=250)
    status = models.CharField(max_length=250)
    data =  models.JSONField(default = dict)
    close_date = models.DateField(("Date"), default=date.today,unique=False)
    class Meta:
        unique_together = ('time_created', 'model_name')



class BacktestPredictions(models.Model):
    model_name = models.ForeignKey(MLModels,
        on_delete=models.CASCADE,
        to_field='name',db_column='modelname')
    predictions = models.JSONField(default = dict)
    time_created = models.DateField(("Date"), default=date.today,unique=False)
    class Meta:
        unique_together = ('time_created', 'model_name')

