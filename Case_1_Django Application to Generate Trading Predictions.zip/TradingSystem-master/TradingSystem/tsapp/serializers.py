from dataclasses import field

from pyexpat import model
from rest_framework import serializers

from .models import ( BacktestPredictions, MLModels, ModelData, Positions,
                     Predictions)


class ModelDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = ModelData
        fields = ('__all__')



class MLModelsSerializer(serializers.ModelSerializer):
    class Meta:
        model = MLModels
        fields = ('__all__')


class PredictionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Predictions
        fields = ('__all__')

class PositionsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Positions
        fields = ('__all__')

class BackTestPredictionSerializer(serializers.ModelSerializer):
    class Meta:
        model = BacktestPredictions
        fields = ('__all__')