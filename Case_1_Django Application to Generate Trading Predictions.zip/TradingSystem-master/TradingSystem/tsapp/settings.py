ALPACA_PAPER_API_KEY = 'your_paper_api_key'
ALPACA_PAPER_SECRET_KEY = 'your_paper_secret_key'
ALPACA_LIVE_API_KEY = 'your_live_api_key'

ALPACA_LIVE_SECRET_KEY = 'your_live_secret_key'
ALPACA_BASE_URL = 'https://api.alpaca.markets'
ALPACA_PAPER_BASE_URL = 'https://paper-api.alpaca.markets'

POLYGON_KEY = "Your Polygon IO Key for data"
