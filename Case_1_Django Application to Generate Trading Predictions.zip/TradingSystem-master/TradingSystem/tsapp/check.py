# # import pandas as pd
# # import requests
# # import json
# # import ast 
# # df= pd.read_csv('/home/fasihgul/TradingSystem/TradingSystem/tsapp/temp/models.csv')
# # df.drop(columns=['Unnamed: 0'],inplace = True)
# # df.rename(columns={'thresh':'threshold'},inplace = True)
# # df['features'] = df['features'].apply(lambda x: ast.literal_eval(x))
# # df['tickers'] = df['tickers'].apply(lambda x: ast.literal_eval(x))
# # df['name'] = df['name'].apply(lambda x: x.replace('&','and'))
# # df['threshold'] = df['threshold'].fillna(0.5)
# # df['scaler_path'] = df['scaler_path'].fillna('None')
# # print(df['threshold'])
# # # print(df['name'].nunique())
# # # df.fillna(' ',inplace = True)
# # print(df['name'])
# # for i in range(0,len(df)):
# #     checkentry = df.iloc[i].to_dict()
# #     print(checkentry['name'],checkentry['threshold'],checkentry['scaler_path'])
# #     requests.post(url='http://127.0.0.1:8000/api/addmodel/',json = checkentry)


# # # requests.get()

# # # resp = requests.get(url='http://127.0.0.1:8000/api/getmodel/?name=0pct&5mil30daymedianvol_Undersampled')
# # # print(resp.json())


# import requests
# requests.post('http://127.0.0.1:8000/api/generateind/',json={'strategy_type':'ls'})
# import numpy as np
# x = np.array([[1],[3]])

# print(x.ravel())
# print(x[:,1])

# import pandas as pd
# val = ['1','1','1']
# x = pd.DataFrame(val,columns=['a'])
# print(x['a'].unique()[0])

# def x():
#     count = 1
#     while True :
#         if count == 9:
#             return count
#         count +=1
    

# print(x())

# from .BrokerAPi import AlpacaBroker

# broker = AlpacaBroker()
# api = broker.get_api()
# api.get_order_by_client_order_id('')

import requests
# requests.patch('http://127.0.0.1:8000/api/closepositions/',json={})
resp = requests.post('http://127.0.0.1:8000/api/generateind/',json={'strategy_type':'ls'})
# requests.patch('http://127.0.0.1:8000/api/shortupdate/',json={'m1':'model-2019-short-0.01-diff-feats','m2':'model-2019-short-0.005'})