import ast
import pickle

import flaml
import pandas as pd
from tensorflow import keras

from .BrokerAPi import AlpacaBroker


class PredictionGenerator():
    def __init__(self,backtest = False) -> None:
        self.backtest = backtest

    def to_use_scaler(self,data):
        return data['scaler_path'] != 'None'

    def load_model(self,data):
        if not 'ann' in data['model_path'].lower():
            with open(data['model_path'],'rb') as f:
                model = pickle.load(f)
        else:
            model = keras.models.load_model(data['model_path'])
        return model

    
    def load_scaler(self,data):
        if self.to_use_scaler(data):
            with open(data['scaler_path'],'rb') as f:
                scaler = pickle.load(f)
                print(scaler)
            return scaler
        else:
            return None



    def get_prediction(self,ind_data,model_data):
        broker = AlpacaBroker()
        try:
            model = self.load_model(model_data)
            scaler = self.load_scaler(model_data)
            model_features = model_data['features']
            model_tickers = model_data['tickers']
            model_type = model_data['side']
            model_threshold = model_data['threshold']
            threshold = 5000000
            if model_type == 'short':
                threshold = 1000000
                ind_data = ind_data[ind_data['ticker'].isin(broker.get_short_list_on_alpaca())]
            ind_data = ind_data[ind_data['ticker'].isin(model_tickers)]
            ind_data = ind_data[ind_data['f_five_days_avg_volume'] >= threshold]   
            model_weight = model_data['weight']

            cols_ = ['ticker','f_five_days_avg_volume']
            if self.backtest :
                cols_ += ['f_OC','f_CC1','f_CC3','Date']
            vol_tic = ind_data[cols_]
                
            ind_data = ind_data[model_features]
            ind_data.rename(columns={'DolVoloverrollingmean30':'DolVol/rollingmean30','DolVoloverrollingmedian30':'DolVol/rollingmedian30'},inplace = True)
            if scaler:
                ind_data = pd.DataFrame(scaler.transform(ind_data),columns = ind_data.columns)
            if model_type != 'short':
                if 'ann' in model_data['name'].lower():
                    predictions = model.predict(ind_data.values).ravel()
                    print("\t\t-------->>>",predictions)
                else:
                    predictions = model.predict_proba(ind_data.values)[:,1]
                predictions = [1 if i>=model_threshold else 0 for i in predictions]
                vol_tic['preds'] = predictions
                vol_tic = vol_tic[vol_tic['preds']==1]
                return vol_tic
            else:
                predictions = model.predict(ind_data.values)
                vol_tic['preds'] = predictions
                vol_tic = vol_tic[vol_tic['preds']==1]
                return vol_tic
        except Exception as e:
            print("************",e)
