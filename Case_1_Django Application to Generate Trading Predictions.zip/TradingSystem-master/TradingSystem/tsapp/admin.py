from django.contrib import admin
from .models import ModelData
admin.site.register(ModelData)

# Register your models here.
