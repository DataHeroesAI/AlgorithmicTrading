import alpaca_trade_api as trade_api
from concurrent.futures import ThreadPoolExecutor
from settings import *
import time
class AlpacaBroker():

    def __init__(self) -> None:
        self.Paper = True
        self.close = False


    def get_api(self):
        Paper = self.Paper

        if Paper:
            key = ALPACA_PAPER_API_KEY
            sec_key = ALPACA_PAPER_SECRET_KEY
            base_url = ALPACA_PAPER_BASE_URL
        else:
            key = ALPACA_LIVE_API_KEY
            sec_key = ALPACA_LIVE_SECRET_KEY
            base_url = ALPACA_BASE_URL

        api = trade_api.REST(key, sec_key, base_url)
        return api 


    def get_active_tickers(self):
        api  = self.get_api()
        active_assets = api.list_assets(status='active')
        return active_assets

    def get_short_list_on_alpaca(self):
        api  = self.get_api()
        active_assets = api.list_assets(status='active')
        short_list = []
        for asset in active_assets:
            if asset.easy_to_borrow and asset.marginable:
                short_list.append(asset.symbol)
        return short_list

    def get_cash_in_hand(self):
        api  = self.get_api()
        return api.get_account().__dict__['_raw']['cash']

    def update_order_details(self,data):
        api = self.get_api()
        results = []

        for i in list(data.keys()):
            print(i)
            if not i == 'errors':
                cloid = data[i]['client_order_id']
                raw = api.get_order_by_client_order_id(cloid).__dict__['_raw']
                results.append(raw)
            
            results_ = {}
            errors = []
            for i in results:
                try:
                    results_[i['symbol']] = {'side':i['side'],'status':i['status'],'filled_qty':i['filled_qty'],'filled_avg_price':i['filled_avg_price'],'client_order_id':i['client_order_id']}
                except:
                    errors.append(i)
                    print("****************",i)
                results_['errors'] = errors    
        return results_



    def submit_order_(self,data):
        try:
            side_ = 'buy' if data[2] == 'long' else 'sell'
            api = self.get_api()
            resp = api.submit_order(symbol=data[0],
                                    qty=data[1],
                                    side=side_,
                                    type='market',
                                    time_in_force='gtc')
            time.sleep(6)
            to_use = ['client_order_id','status','submitted_at','side','qty']
            raw = resp.__dict__['_raw']
            complete_status = 'filled'

            if side_ == 'sell' and (not self.close):
                complete_status = 'accepted'
                
            if raw['status'] != complete_status :
                while True:
                    raw = api.get_order_by_client_order_id(raw['client_order_id']).__dict__['_raw']
                    if raw['status'] == complete_status or raw['status'] == 'filled' :
                        break
                    time.sleep(6)
                    print("Waiting for order to fill",raw['status'])

            return raw    
        except Exception as e:
            print('Error In submiting Order Please check ',data,e)
            return e
        
    def open_positions(self,positions,close=False):
        if close :
            self.close = True
        with ThreadPoolExecutor(max_workers=30) as pool:
            results = pool.map(self.submit_order_, positions)
        results_ = {}
        errors = []
        for i in results:
            try:
                results_[i['symbol']] = {'side':i['side'],'status':i['status'],'filled_qty':i['filled_qty'],'filled_avg_price':i['filled_avg_price'],'client_order_id':i['client_order_id']}
            except:
                errors.append(i)
                print("****************",i)
            results_['errors'] = errors


        return results_
