import requests
import pandas as pd
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timedelta
import time 
from settings import *

class DataDownload():
    
    def __init__(self) -> None:
        self.source = "Polygon"
    
    
    def get_hist(self,name, date_back, date_today):
        try:
            url = f'''https://api.polygon.io/v2/aggs/ticker/{name}/range/1/day/{date_back}/{date_today}?adjusted=true&sort=asc&limit=50000&apiKey={POLYGON_KEY}'''
            response = requests.get(url)
            hist = pd.DataFrame(response.json()['results'])

            hist.rename(columns={
                'c': 'Close',
                't': 'Date',
                'v': 'Volume',
                'o': 'Open',
                'h': 'High',
                'l': 'Low'
            },
                        inplace=True)
            hist['Date'] = pd.to_datetime(hist['Date'], unit='ms')
            hist['Date'] = hist['Date'].dt.tz_localize('UTC')
            hist['Date'] = hist['Date'].dt.tz_convert('US/Eastern')
            hist['Date'] = hist['Date'].dt.tz_localize(None)

            hist.set_index('Date', inplace=True)
            hist  = hist[hist.index>'2019-01-01']
            if len(hist)==0:
                return None
            return hist

        except Exception as e:
            print(e,response.json())
            return hist


    def prefetch(self,data_):
        try:
            ticker = data_[0]
            prev = data_[1]
            today = data_[2]
            maps_ = data_[3]
        except Exception as e:
            print(e)
        try:
            url = f'''https://api.polygon.io/v2/aggs/ticker/{ticker}/range/1/day/{prev}/{today}?adjusted=true&sort=asc&limit=50000&apiKey=7J0OvsRHy0svTgU30022h58Y04nPds2s'''
            response = requests.get(url)
            hist = pd.DataFrame(response.json()['results'])

            hist.rename(columns={
                'c': 'Close',
                't': 'Date',
                'v': 'Volume',
                'o': 'Open',
                'h': 'High',
                'l': 'Low'
            },
                        inplace=True)
            hist['Date'] = pd.to_datetime(hist['Date'], unit='ms')
            hist['Date'] = hist['Date'].dt.tz_localize('UTC')
            hist['Date'] = hist['Date'].dt.tz_convert('US/Eastern')
            hist['Date'] = hist['Date'].dt.tz_localize(None)
            hist['ticker'] = ticker
            hist.set_index('Date', inplace=True)
            hist = hist[hist.index>'2019-01-01']
            if len(hist)==0:
                return None
            return hist[['Close','Volume','Open','High','Low','ticker']]

        except Exception as e:
            print(e,ticker)
            # print(e,response,ticker)
            return None 



    def prefetch_v(self,data_):
        try:
            ticker = data_
            prev = str(datetime.today().date())
            today = prev
        except Exception as e:
            print(e)
        try:
            url = f'''https://api.polygon.io/v2/aggs/ticker/{ticker}/range/1/day/{prev}/{today}?adjusted=true&sort=asc&limit=50000&apiKey={POLYGON_KEY}'''
            
            response = requests.get(url)
            hist = pd.DataFrame(response.json()['results'])

            hist.rename(columns={
                'c': 'Close',
                't': 'Date',
                'v': 'Volume',
                'o': 'Open',
                'h': 'High',
                'l': 'Low'
            },
                        inplace=True)
            hist['Date'] = pd.to_datetime(hist['Date'], unit='ms')
            hist['Date'] = hist['Date'].dt.tz_localize('UTC')
            hist['Date'] = hist['Date'].dt.tz_convert('US/Eastern')
            hist['Date'] = hist['Date'].dt.tz_localize(None)
            hist['ticker'] = ticker
            hist.set_index('Date', inplace=True)
            print({ticker:hist['Close'].iloc[0]})
            return {ticker:hist['Close'].iloc[0]}
            # return hist[['Close','ticker']]
        except Exception as e:
            print(e,response,ticker)
            return None 
            # return hist



