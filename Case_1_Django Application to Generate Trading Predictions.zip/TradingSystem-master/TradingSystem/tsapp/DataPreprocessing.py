from hashlib import new
import pickle
import warnings
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta

import numpy as np
import pandas as pd
import talib
from joblib import Parallel, delayed, parallel_backend
from tqdm import tqdm

from .BrokerAPi import AlpacaBroker
from .DataDownloader import DataDownload
from django.conf import settings
import os,gc


class GenerateFeatures():

    def __init__(self,tickers=None,backtest = False,all_features = None) -> None:
        temp = os.path.join(settings.BASE_DIR ,"tsapp/temp/ticker_maps_td.pickle")
        self.all_ticker_path = temp
        self.all_tickers = tickers
        self.time_diff = 90
        self.thread_poll_workers = 100
        self.backtest = backtest
        self.all_features = all_features + ['f_ticker','ticker','Date','f_five_days_avg_volume']
        self.all_features = list(set(self.all_features))
        if self.backtest:
            self.time_diff = 365*5
            self.all_features = self.all_features + ['f_ticker','ticker','Date','f_OC','f_CC1','f_CC3','f_five_days_avg_volume']
            self.all_features = list(set(self.all_features))
        

    def get_mean(self,x):
        trend = []
        for i in x.keys():
            if 'trend' in i:
                trend.append(x[i])
        return np.mean(trend)

    def get_all_tickers(self):
        with open(self.all_ticker_path,'rb') as f:
            file_ = pickle.load(f)
        return file_



    def generate_features_long(self,data_):
        try:
            warnings.filterwarnings('ignore')
            temp = data_[0]
            ticker = data_[1]
            maps_ = data_[2]
            today = data_[3]
            tic = ticker
            hist = temp.copy()
            hist['Volume'] = hist['Close'] * hist['Volume']
            hist['five_days_avg_volume'] = hist['Volume'].rolling(30).median()
            for i in range(1, 36, 1):
                hist['trend_' + str(i) + '_days'] = hist['Close'] / \
                    hist['Close'].shift(i)
            hist['invest'] = hist.apply(lambda x: self.get_mean(x), axis=1)
            hist['invest_diff'] = hist['invest'].diff(1)
            hist['invest_diff_mean5'] = hist['invest_diff'].rolling(10).mean()
            hist['five_days_avg_volume_log'] = np.log(hist['five_days_avg_volume'])
            if self.backtest:
                hist['OC'] = (hist['Close'] -  hist['Open'])/hist['Close']
                hist['CC1'] = hist['Close'].pct_change()
                hist['CC3'] = hist['Close'].pct_change(3)
                hist['OC'] = hist['OC'].shift(-1)
                hist['CC1'] = hist['CC1'].shift(-1)
                hist['CC3'] = hist['CC3'].shift(-3)
            try:
                hist['ticker'] = maps_[ticker]
            except:
                hist['ticker'] = ticker

            hist.dropna(inplace=True)
            hist = hist.add_prefix('f_')
            hist.reset_index(inplace = True)


            temp = temp.add_prefix(ticker+'_')
            var2 = tic+'_Close'
            upperband, middleband, lowerband = talib.BBANDS(
                temp[var2], timeperiod=5, nbdevup=2, nbdevdn=2, matype=0)
            temp[tic+'_CloseWrtUpperband'] = temp[var2]/upperband
            temp[tic+'_CloseWrtLowerband'] = temp[var2]/lowerband
            temp[tic+'_CloseWrtMiddleband'] = temp[var2]/middleband
            temp[tic+'_UpperbandWrtLowerband'] = upperband/lowerband
            # make atr indicators
            varHigh = temp[tic+'_High']
            varLow = temp[tic+'_Low']
            varClose = temp[tic+'_Close']
            atr14 = talib.ATR(varHigh, varLow, varClose, timeperiod=14)
            atr21 = talib.ATR(varHigh, varLow, varClose, timeperiod=21)
            temp[tic+'_CloseWrtAtr14'] = varClose/atr14
            temp[tic+'_CloseWrtAtr21'] = varClose/atr21

            # make mfi indicators
            varVolume = temp[tic+'_Volume']
            mfi14 = talib.MFI(varHigh, varLow, varClose, varVolume, timeperiod=14)
            temp[tic+'_Mfi14'] = mfi14

            # make Close %ch OR target one day ahead pct ch as shifted
            var2 = tic+'_Close'
            var3 = var2+'Pct'
            temp[var3] = temp[var2].pct_change().shift(-1)
            temp[tic+'_CloseRatio'] = (temp[tic+'_Close'] /
                                    temp[tic+'_Close'].shift(1)).shift(-1)

            # make lags of close
            for j in np.arange(1, 40):
                var = tic+'_lagClose'+str(j)
                var2 = tic+'_Close'
                temp[var] = temp[var2].shift(j)

            # make lags of closeRatio
            for j in np.arange(1, 40):
                var = tic+'_lagCloseRatio'+str(j)
                var2 = tic+'_CloseRatio'
                temp[var] = temp[var2].shift(j)

            # make ratio of curr close wrt prev n
            lagCloseCols = pd.Series(temp.columns)
            lagCloseCols = list(lagCloseCols[(lagCloseCols.str.contains(
                'lagClose')) & ~(lagCloseCols.str.contains('lagCloseRatio'))])


            for j in np.arange(1, len(lagCloseCols)+1):
                var2 = tic+'_lagClose'+str(j)
                var = tic+'_currCloseWrtPrev'+str(j)
                temp[var] = temp[tic+'_Close']/temp[var2]

            # make ratios means
            lagCloseRatioCols = pd.Series(temp.columns)
            lagCloseRatioCols = list(
                lagCloseRatioCols[lagCloseRatioCols.str.contains('_lagCloseRatio')])

            # print('lagCloseRatioCols', lagCloseRatioCols)

            for k in np.arange(2, len(lagCloseRatioCols)+1):
                var3 = tic+'_lagCloseRatio'+str(k)+'Mean'
                temp[var3] = temp[lagCloseRatioCols[:k]].mean(axis=1)

            # make means of ratio of curr close wrt prev n
            currCloseWrtCols = pd.Series(temp.columns)
            currCloseWrtCols = list(
                currCloseWrtCols[currCloseWrtCols.str.contains('_currCloseWrtPrev')])

            for k in np.arange(2, len(currCloseWrtCols)+1):
                var3 = tic+'_currCloseWrtPrev'+str(k)+'Mean'
                temp[var3] = temp[currCloseWrtCols[:k]].mean(axis=1)

            # make $ volume
            volvar = tic+'_Volume'
            volclose = tic+'_Close'
            dolvol = tic+'_DolVol'
            temp[dolvol] = (temp[volvar]*temp[volclose]).astype(int)

            temp[tic+'_DolVolRatio'] = (temp[tic+'_DolVol'] /
                                        temp[tic+'_DolVol'].shift(1)).shift(-1)

            temp = temp[~temp[tic+'_DolVolRatio'].isin([np.inf])]

            # make lags of $ vol
            for j in np.arange(1, 40):
                var = tic+'_lagDolVol'+str(j)
                var2 = tic+'_DolVol'
                temp[var] = temp[var2].shift(j)

            # make lags of $ volRatio
            for j in np.arange(1, 40):
                var = tic+'_lagDolVolRatio'+str(j)
                var2 = tic+'_DolVolRatio'
                temp[var] = temp[var2].shift(j)

            # make ratio of curr $ vol wrt prev n
            lagDolVolCols = pd.Series(temp.columns)
            lagDolVolCols = list(lagDolVolCols[(lagDolVolCols.str.contains(
                'lagDolVol')) & ~ (lagDolVolCols.str.contains('lagDolVolRatio'))])


            for j in np.arange(1, len(lagDolVolCols)+1):
                var2 = tic+'_lagDolVol'+str(j)
                var = tic+'_currDolVolWrtPrev'+str(j)
                temp[var] = temp[tic+'_DolVol']/temp[var2]

            lagDolVolRatioCols = pd.Series(temp.columns)
            lagDolVolRatioCols = list(
                lagDolVolRatioCols[lagDolVolRatioCols.str.contains('_lagDolVolRatio')])

            for k in np.arange(2, len(lagDolVolRatioCols)+1):
                var3 = tic+'_lagDolVolRatio'+str(k)+'Mean'
                temp[var3] = temp[lagDolVolRatioCols[:k]].mean(axis=1)

            currDolVolWrtCols = pd.Series(temp.columns)
            currDolVolWrtCols = list(
                currDolVolWrtCols[currDolVolWrtCols.str.contains('_currDolVolWrtPrev')])


            for k in np.arange(2, len(currDolVolWrtCols)+1):
                var3 = tic+'_currDolVolWrtPrev'+str(k)+'Mean'
                temp[var3] = temp[currDolVolWrtCols[:k]].mean(axis=1)



            temp[dolvol+'rollingmean5'] = temp[dolvol].rolling(5).mean()
            temp[dolvol+'rollingmean15'] = temp[dolvol].rolling(15).mean()
            temp[dolvol+'rollingmean39'] = temp[dolvol].rolling(39).mean()


            rm5 = dolvol+'rollingmean5'
            temp.loc[(temp[rm5] < 5000000), tic+'_encodedDVRm5'] = 0

            temp.loc[(temp[rm5] >= 5000000), tic+'_encodedDVRm5'] = 1

            rm15 = dolvol+'rollingmean15'
            temp.loc[(temp[rm15] < 5000000), tic+'_encodedDVRm15'] = 0

            temp.loc[(temp[rm15] >= 5000000), tic+'_encodedDVRm15'] = 1

            rm39 = dolvol+'rollingmean39'
            temp.loc[(temp[rm39] < 5000000), tic+'_encodedDVRm39'] = 0

            temp.loc[(temp[rm39] >= 5000000), tic+'_encodedDVRm39'] = 1

            temp.drop([rm5, rm15, rm39], inplace=True, axis=1)

            temp[dolvol+'rollingmean5'] = temp[dolvol].rolling(5).mean()
            
            temp[dolvol+'rollingmean30']=temp[dolvol].rolling(30).mean()
                        
            temp[dolvol+'rollingmedian30']=temp[dolvol].rolling(30).median()

            t1=dolvol+'rollingmean30'
            t2=dolvol+'rollingmedian30'

            temp[dolvol+'overrollingmean30']=temp[dolvol]/temp[dolvol+'rollingmean30']

            temp[dolvol+'overrollingmedian30']=temp[dolvol]/temp[dolvol+'rollingmedian30']


            temp.drop([t1, t2], inplace=True, axis=1)
            
            
            temp[dolvol+'rollingmedian30']=temp[dolvol].rolling(30).median()

            temp.drop([tic+'_CloseRatio', tic+'_ClosePct',
                    tic+'_DolVolRatio'], inplace=True, axis=1)

            temp.dropna(inplace=True)

            temp.reset_index(inplace=True)

            temp[tic+'_ticker'] = tic
            d = tic+'_Date'
            temp.rename(columns={'Date': d}, inplace=True)
            temp.columns = [i.split('_')[1] for i in temp.columns]
            


            if not self.backtest:
                if len(temp[temp['Date'] == today]) == 0 :
                    # print("Shite")
                    return (None,None)


            if not self.backtest:
                merged = pd.merge(temp[temp['Date' ] == today],hist[hist['Date']== today],on= 'Date',how = 'inner')
                merged = merged[self.all_features]
                return (merged.values[0],list(merged.columns))
            else:
                merged = pd.merge(temp,hist,on = 'Date',how = 'inner')
                merged = merged[self.all_features]
                return (merged.values,list(merged.columns))

        except Exception as e:
            print("OLLL",e)
            return (None,None)

    

    def generate_data(self,data):
        try:
            broker = AlpacaBroker()
            date_today = datetime.utcnow().date()
            all_tickers_maps =  self.get_all_tickers()
            all_tickers = list(all_tickers_maps.keys())
            active_tickers = broker.get_active_tickers()
            active_tickers = [i.symbol for i in active_tickers]
            all_tickers = list(set(active_tickers) & set(all_tickers))
            print('Active Tickers : ',len(all_tickers))
            if self.backtest:
                all_tickers = self.all_tickers
            
            date_today = datetime.utcnow()
            date_last = date_today - timedelta(days=self.time_diff)
            date_last = str(date_last.date())
            date_today = str(date_today.date())
            stocks = [(ticker,date_last,date_today,all_tickers_maps) for ticker in all_tickers]
            print("length Of stocks ",date_last,date_today)
            with ThreadPoolExecutor(max_workers=self.thread_poll_workers) as pool:
                data_downloader = DataDownload()
                results = pool.map(data_downloader.prefetch, stocks)
            try:
                results = [(i , i['ticker'].unique()[0] , all_tickers_maps , date_today) for i in results if isinstance(i,pd.DataFrame)  ]

            except Exception as e:
                print('---',e)
            

            print("length of Raw Results ",len(results))
            try:
                with parallel_backend('loky', n_jobs=-1):
                    new_results = Parallel()(delayed(self.generate_features_long)(i) for i in tqdm(results))
            except Exception as e:
                print("Exception Occured",e)
            del results
            try:
                cols = None
                for i in new_results:
                    if isinstance(i[0],np.ndarray):
                        cols = i[1]

                new_results = [i[0] for i in new_results if isinstance(i[0],np.ndarray)]

                temp_res = []

                if self.backtest:
                    for res in tqdm(range(0,len(new_results))):
                        temp_res += new_results[res].tolist()

                    new_results = temp_res
                del temp_res                  


            except Exception as e:
                print("Exception Ocured",e)
            df  = pd.DataFrame(new_results,columns=cols)
            del new_results
            gc.collect()
            return df
        except Exception as e :
            print(e)
            return e
